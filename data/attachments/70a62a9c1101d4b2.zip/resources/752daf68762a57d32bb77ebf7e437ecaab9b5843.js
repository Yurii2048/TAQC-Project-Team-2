function s(t,i){return t.queryParams.subscribe(e=>{let o=e.isBookmark==="true",n=e.section||"news";i(o,n)})}export{s as a};
